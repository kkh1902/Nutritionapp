// 음식 추가 액티비티
package com.example.project;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddFoodActivity extends AppCompatActivity {

    private static final String TAG = "AddFoodActivity";
    private String month, day, date;
    private ArrayList<ModelListFood> arrayList;
    private Intent intent;
    private InputMethodManager imm;
    private AppCompatButton btn_search;
    private EditText select;
    private ImageButton btn_back;
    private ListView addlist;
    private RelativeLayout progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addfood);

        intent = getIntent();

        month = intent.getExtras().getString("sel_month");
        day = intent.getExtras().getString("sel_day");
        date = month + day;

        btn_back = (ImageButton) findViewById(R.id.addfood_btn_back);
        btn_search = (AppCompatButton) findViewById(R.id.addfood_btn_search);
        select = (EditText) findViewById(R.id.addfood_search);
        addlist = (ListView) findViewById(R.id.addfood_list_addlist);
        progress = (RelativeLayout) findViewById(R.id.addfood_progress);
        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

        arrayList = new ArrayList<ModelListFood>();
        AdapterListFood arrayAdapter = new AdapterListFood(this, arrayList);
        Interface interfaces = Client.getRetrofitInstance().create(Interface.class);

        addlist.setAdapter(arrayAdapter);

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                select.setCursorVisible(true);
            }
        });

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.go_up_1, R.anim.go_up_2);
                finish();
            }
        });

        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp_selected = select.getText().toString();
                arrayList.clear();
                select.setCursorVisible(false);
                imm.hideSoftInputFromWindow(select.getWindowToken(), 0);
                progress.setVisibility(View.VISIBLE);
                Call<Model> call = interfaces.getAllData(temp_selected, "1", "10", "json");
                call.enqueue(new Callback<Model>() {
                    @Override
                    public void onResponse(Call<Model> call, Response<Model> response) {
                        Model.Body body = response.body().getBody();
                        ArrayList<Model.Body.Items> items = body.getItems();

                        for (int i=0; i < items.toArray().length; i++) {
                            String temp_desc_kor = items.get(i).getDESC_KOR();
                            String temp_service_wt = items.get(i).getSERVING_WT();
                            String temp_nutr_cont1 = items.get(i).getNUTR_CONT1();
                            String temp_nutr_cont2 = items.get(i).getNUTR_CONT2();
                            String temp_nutr_cont3 = items.get(i).getNUTR_CONT3();
                            String temp_nutr_cont4 = items.get(i).getNUTR_CONT4();
                            String temp_attribute = "1회 제공량 : " + temp_service_wt + " / 칼로리 : " + temp_nutr_cont1 + "\n탄수화물 : " + temp_nutr_cont2 + " / 단백질 : " + temp_nutr_cont3 + " / 지방 : " + temp_nutr_cont4;
                            arrayList.add(new ModelListFood(temp_desc_kor, temp_attribute, temp_service_wt, temp_nutr_cont1, temp_nutr_cont2, temp_nutr_cont3, temp_nutr_cont4));
                        }
                        arrayAdapter.notifyDataSetChanged();
                        progress.setVisibility(View.GONE);
                    }

                    @Override
                    public void onFailure(Call<Model> call, Throwable t) {
                        Log.e(TAG, "onFailure: " + t.getMessage());
                        progress.setVisibility(View.GONE);
                    }
                });
            }
        });

        addlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ModelListFood sel_food = (ModelListFood) arrayAdapter.getItem(i);
                intent = new Intent(getApplicationContext(), ModalActivity.class);
                intent.putExtra("sel_food_name", sel_food.getFood_name());
                intent.putExtra("sel_food_attrib", sel_food.getFood_attribute());
                intent.putExtra("sel_food_service_wt", sel_food.getFood_service_wt());
                intent.putExtra("sel_food_kcal", sel_food.getFood_kcal());
                intent.putExtra("sel_food_tan", sel_food.getFood_tan());
                intent.putExtra("sel_food_dan", sel_food.getFood_dan());
                intent.putExtra("sel_food_ji", sel_food.getFood_ji());
                intent.putExtra("date", date);
                startActivity(intent);
                overridePendingTransition(R.anim.fadein, R.anim.fadeout);
            }
        });
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.go_up_1, R.anim.go_up_2);
        finish();
    }
}
